<?php
echo "Error! Please Manually Copy Your Wordpress Files or reinstall";
phpinfo();